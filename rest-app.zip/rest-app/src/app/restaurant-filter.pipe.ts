import { Pipe, PipeTransform } from '@angular/core';
import { IRestaurant } from './restaurant';

@Pipe({
  name: 'restaurantFilter'
})
export class RestaurantFilterPipe implements PipeTransform {

  transform(value: IRestaurant[], filterBy: string): IRestaurant[] {
    filterBy= (filterBy)? filterBy.toLocaleLowerCase() : null;
    return (filterBy) ? value.filter(
      (restaurant : IRestaurant) => 
       restaurant.restaurantTitle
       .toLocaleLowerCase()
       .indexOf(filterBy)!== -1)
      :value;
  }

}
