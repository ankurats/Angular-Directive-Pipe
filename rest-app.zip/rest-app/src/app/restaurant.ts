export interface IRestaurant {
    restaurantId: number;
    restaurantTitle: string;
    restaurantCity: string;
    restaurantState: string;
    starRating: number;
    imageUrl: string;
}
